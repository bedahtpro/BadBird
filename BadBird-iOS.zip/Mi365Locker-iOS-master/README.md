# Mi365Locker-iOS
Mi365Locker PoC application for iOS, build using Adafruit BLE Client for iOS 

# Basic-Chat
Bluetooth Low Energy App for iOS using Swift.
Looking to learn how Bluetooth Low Energy works in iOS & Swift 3? Well look no farther, we've got what you've been waiting for!
